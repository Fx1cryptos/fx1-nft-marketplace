export default function Home() {
  return (
    <main>
      <h1>FX1 HUBS MINIAPP</h1>
      <p>Styling the Blockchain & Metaverse — Powered by $FDH</p>
    </main>
  );
}
