export const getPinataURL = (cid: string) => 
  `https://gateway.pinata.cloud/ipfs/${cid}`;
