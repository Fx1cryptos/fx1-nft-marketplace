# FX1 Digital Hubs - NFT Starter (Base Sepolia & Mainnet)

This project includes an ERC-721 contract supporting free and paid minting, limited supply, and a Vite + React frontend for minting from browser wallets.

## Features
- Contract name: FX1NFT (FX1 Digital Hubs) - symbol FDH
- Max supply: configurable (default 1000)
- Paid mint price: configurable (default 0.01 ETH)
- Free mint & paid mint toggles
- Deploy scripts for Base Sepolia & Base Mainnet
- Simple Vite React frontend (wallet connect via window.ethereum + ethers)

## Quickstart
1. Install root deps for contracts:
```bash
npm install
```

2. Install frontend deps:
```bash
cd frontend
npm install
```

3. Copy `config/.env.example` to `.env` and fill your PRIVATE_KEY and RPC endpoints.

4. Compile & deploy to Sepolia (testnet):
```bash
npx hardhat compile
npx hardhat run scripts/deploy.js --network baseSepolia
```

5. Run frontend locally:
```bash
cd frontend
npm run dev
```

## Notes
- This starter is designed to be extended. The contract uses simple batch minting loops. For production, consider gas optimizations (ERC721A) and security audits.
- Do NOT commit private keys.

Built for FX1 DIGITAL HUBS.
