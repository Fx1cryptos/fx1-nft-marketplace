// Example script to call mint functions (after deployment)
const hre = require("hardhat");

async function main() {
  const [user] = await hre.ethers.getSigners();
  const fx1Address = process.env.FX1_ADDRESS;
  if (!fx1Address) { console.error("set FX1_ADDRESS in env"); return; }
  const FX1 = await hre.ethers.getContractAt("FX1NFT", fx1Address);

  // Example: paid mint 1 to user with an example URI
  const tx = await FX1.connect(user).mintPaid(1, user.address, ["ipfs://QmExampleMetadata"], { value: hre.ethers.parseEther("0.01") });
  await tx.wait();
  console.log("Minted paid NFT to", user.address);
}

main().catch(e => { console.error(e); process.exitCode = 1; });
