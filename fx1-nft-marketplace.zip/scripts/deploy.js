// Deploy FX1NFT contract
const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const name = "FX1 Digital Hubs";
  const symbol = "FDH";
  const maxSupply = 1000;
  // default mint price: 0.01 ETH (wei)
  const mintPrice = hre.ethers.parseEther("0.01");
  const baseURI = "ipfs://";

  const FX1 = await hre.ethers.getContractFactory("FX1NFT");
  const fx1 = await FX1.deploy(name, symbol, maxSupply, mintPrice, baseURI);
  await fx1.waitForDeployment ? await fx1.waitForDeployment() : await fx1.deploymentTransaction().wait();
  console.log("FX1NFT deployed to:", fx1.target || fx1.address);

  console.log("Done");
}

main().catch(e => { console.error(e); process.exitCode = 1; });
