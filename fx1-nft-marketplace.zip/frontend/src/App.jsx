import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import FX1ABI from './FX1ABI.json';

export default function App() {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [address, setAddress] = useState('');
  const [fx1, setFx1] = useState(null);
  const [mintPrice, setMintPrice] = useState('0');
  const [totalMinted, setTotalMinted] = useState(0);
  const [qty, setQty] = useState(1);
  const [tokenURIs, setTokenURIs] = useState('ipfs://QmExampleMetadata');

  const FX1_ADDRESS = import.meta.env.VITE_FX1_ADDRESS || '';

  useEffect(()=>{
    if (window.ethereum) {
      const p = new ethers.BrowserProvider(window.ethereum);
      setProvider(p);
    }
  },[]);

  useEffect(()=>{
    (async ()=>{
      if (!provider || !FX1_ADDRESS) return;
      const contract = new ethers.Contract(FX1_ADDRESS, FX1ABI, provider);
      setFx1(contract);
      try {
        const price = await contract.mintPrice();
        setMintPrice(ethers.formatEther(price));
        const minted = await contract.totalMinted();
        setTotalMinted(Number(minted));
      } catch(e){ console.log(e); }
    })();
  }, [provider]);

  const connect = async ()=>{
    if (!window.ethereum) return alert('Please install a wallet');
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const p = new ethers.BrowserProvider(window.ethereum);
    const s = await p.getSigner();
    const a = await s.getAddress();
    setSigner(s);
    setAddress(a);
    if (FX1_ADDRESS) {
      const contractWithSigner = new ethers.Contract(FX1_ADDRESS, FX1ABI, s);
      setFx1(contractWithSigner);
    }
  };

  const handlePaidMint = async ()=>{
    if (!fx1 || !signer) return alert('Connect wallet & set FX1 address in .env');
    const qtyNum = Number(qty);
    const uris = new Array(qtyNum).fill(tokenURIs);
    const tx = await fx1.mintPaid(qtyNum, address, uris, { value: ethers.parseEther(String(mintPrice*qtyNum)) });
    await tx.wait();
    alert('Paid mint successful!');
  };

  const handleFreeMint = async ()=>{
    if (!fx1 || !signer) return alert('Connect wallet & set FX1 address in .env');
    const qtyNum = Number(qty);
    const uris = new Array(qtyNum).fill(tokenURIs);
    const tx = await fx1.mintFree(qtyNum, address, uris);
    await tx.wait();
    alert('Free mint successful!');
  };

  return (
    <div style={{fontFamily:'sans-serif', padding:20}}>
      <h1>FX1 Digital Hubs — Mint</h1>
      <p>Contract: <b>{FX1_ADDRESS || 'Set VITE_FX1_ADDRESS in .env'}</b></p>
      <p>Total minted: {totalMinted}</p>
      <p>Mint price (ETH): {mintPrice}</p>
      <button onClick={connect}>{address ? 'Connected: '+address : 'Connect Wallet'}</button>
      <div style={{marginTop:20}}>
        <label>Quantity</label><br/>
        <input type="number" value={qty} min="1" onChange={(e)=>setQty(e.target.value)}/><br/>
        <label>Token URI (ipfs://...)</label><br/>
        <input style={{width:'100%'}} value={tokenURIs} onChange={(e)=>setTokenURIs(e.target.value)}/><br/>
        <button onClick={handleFreeMint} style={{marginRight:10}}>Free Mint</button>
        <button onClick={handlePaidMint}>Paid Mint</button>
      </div>
      <hr/>
      <p>Note: This is a starter UI. For production, integrate better UX and error handling.</p>
    </div>
  )
}
