# Frontend (Vite + React)

Set VITE_FX1_ADDRESS in .env to your deployed contract address.

Run:
```bash
npm install
npm run dev
```

Open http://localhost:5173
