<!-- PROJECT BANNER -->
<p align="center">
  <img src="https://gateway.pinata.cloud/ipfs/bafybeid5mdc6emwyfahsglafto2c2ohomm3svv6wgx4uza7gep7jdiyuxu" alt="FX1 NFT Marketplace Banner" width="100%">
</p>

# 🖼️ FX1 NFT Marketplace — BASE BUILDER

**FX1 Digital Hubs (FX1)** — Blockchain Artist • NFT Creator • Digital Fashion Innovator • Web3 Growth Strategist • **BASE BUILDER**

A decentralized NFT Marketplace built on **Base** and powered by **$FDH** (FX1 Digital Hubs Token).  
Free & Paid minting • Limited Supply Collections • Onchain Fashion & Art.

---

## 🚀 Quick Links
- 🌐 Website: https://fx1hubs.short.gy  
- 🟣 Farcaster: https://farcaster.xyz/fx1-faucet  
- 💬 Telegram: https://t.me/fx1digitalhubs  
- 🐦 X (Twitter): https://x.com/fx1_hubs?s=21  
- 🎮 Discord: https://discord.gg/gAQFRfdu  
- 🎥 TikTok: https://www.tiktok.com/@fx1_hubs?_t=ZS-8z9q5FXQJjl&_r=1  
- 🖌️ Zora: https://zora.co/@fx1_hubs  
- 🔗 GitHub: https://github.com/Fx1cryptos/fx1-nft-marketplace.git

---

## 🪙 Token — $FDH
<p align="center">
  <img src="https://gateway.pinata.cloud/ipfs/bafybeicxaddlgd7hibu42fifvw7axfwrkkvesfqnlpg6h5fkpsnec4vzcu" alt="$FDH Token Logo" width="200">
</p>

- **Name:** FX1 Digital Hubs Token ($FDH)  
- **Contract (Base Mainnet):** `0x1f85705d939Bb6Fa1AEbE99d7105AdCee75CE380`  
- View on Rainbow: https://rainbow.me/token/base/0x1f85705d939Bb6Fa1AEbE99d7105AdCee75CE380

---

## ⚡ Features
- ERC-721 NFT collection with free mint & paid mint options  
- Limited supply collections (default: 1,000 NFTs)  
- Frontend: React + Vite — wallet connect & mint UI  
- Deployable to **Base Sepolia** (testnet) & **Base Mainnet** (production)

---

## 🛠 Tech
- Solidity (Hardhat) for contracts  
- React + Vite frontend (ethers.js)  
- IPFS / Pinata for metadata storage  
- Alchemy RPC for Base (deployment)

---

## 🧭 Quickstart (local)
1. Clone repo:
```bash
git clone https://github.com/Fx1cryptos/fx1-nft-marketplace.git
cd fx1-nft-marketplace
```

2. Install root dependencies:
```bash
npm install
```

3. Fill `.env` (see `.env.example`) with your `PRIVATE_KEY` and RPC values.

4. Compile contracts:
```bash
npx hardhat compile
```

5. Deploy to Sepolia (test):
```bash
npx hardhat run scripts/deploy.js --network baseSepolia
```

6. Deploy to Mainnet (when ready):
```bash
npx hardhat run scripts/deploy.js --network baseMainnet
```

7. Frontend:
```bash
cd frontend
npm install
npm run dev
```

---

## 🔗 Marketplaces (after deploy)
- OpenSea (Base): `https://opensea.io/assets/base/<CONTRACT_ADDRESS>/<TOKEN_ID>`
- Zora: `https://zora.co/contract/<CONTRACT_ADDRESS>`

---

## .env.example
Copy `.env.example` to `.env` and fill values (DO NOT COMMIT `.env`).

```
BASE_MAINNET_RPC=https://base-mainnet.g.alchemy.com/v2/IIcMSrBxe9qC3niaD6AkfvICxIV6hO-M
BASE_SEPOLIA_RPC=https://sepolia.base.org

PRIVATE_KEY=your_private_key_here
BASESCAN_API_KEY=your_basescan_api_key_here

FX1_NFT_ADDRESS=
MARKETPLACE_ADDRESS=
VITE_FX1_ADDRESS=
```

---

## 🤝 Collaborations
Open to Base-native collaborations, metaverse fashion collabs, and DAO partnerships.  
DM via any link above.

---

<p align="center">
🖤 FX1 Digital Hubs – *BASE BUILDER. Creating the Future, Onchain.*
</p>
