import React, {useState} from 'react';
import { ethers } from 'ethers';
import FX1ABI from '../FX1ABI.json';

export default function MintNFT() {
  const [qty, setQty] = useState(1);
  const [uri, setUri] = useState('ipfs://');
  const [status, setStatus] = useState('');

  const FX1_ADDRESS = import.meta.env.VITE_FX1_ADDRESS || '';

  const connectAndMint = async (free) => {
    if (!window.ethereum) return alert('Install a wallet');
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const contract = new ethers.Contract(FX1_ADDRESS, FX1ABI, signer);
    try {
      setStatus('Sending tx...');
      if (free) {
        const tx = await contract.mintFree(uri, { gasLimit: 300000 });
        await tx.wait();
      } else {
        const price = await contract.mintPrice();
        const tx = await contract.mintPaid(uri, { value: price, gasLimit: 300000 });
        await tx.wait();
      }
      setStatus('Mint successful!');
    } catch (e) {
      setStatus('Error: ' + e.message);
    }
  };

  return (
    <div>
      <h2>Mint</h2>
      <label>Token URI</label><br/>
      <input value={uri} onChange={(e)=>setUri(e.target.value)} style={{width:'100%'}}/><br/><br/>
      <button onClick={()=>connectAndMint(true)} style={{marginRight:10}}>Free Mint</button>
      <button onClick={()=>connectAndMint(false)}>Paid Mint</button>
      <p>{status}</p>
    </div>
  );
}
