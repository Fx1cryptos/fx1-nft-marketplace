import React, {useState, useEffect} from 'react';
import MintNFT from './components/MintNFT';

const BANNER = "https://gateway.pinata.cloud/ipfs/bafybeid5mdc6emwyfahsglafto2c2ohomm3svv6wgx4uza7gep7jdiyuxu";
const TOKEN = "https://gateway.pinata.cloud/ipfs/bafybeicxaddlgd7hibu42fifvw7axfwrkkvesfqnlpg6h5fkpsnec4vzcu";

export default function App() {
  return (
    <div style={fontFamily:'sans-serif'}>
      <header style={textAlign:'center', padding:20}>
        <img src={BANNER} alt="FX1 Banner" style={width:'100%', maxHeight:300, objectFit:'cover'}/>
        <img src={TOKEN} alt="$FDH Logo" style={width:120, marginTop:10}/>
        <h1>FX1 NFT Marketplace</h1>
      </header>
      <main style={padding:20}>
        <MintNFT />
      </main>
    </div>
  );
}
