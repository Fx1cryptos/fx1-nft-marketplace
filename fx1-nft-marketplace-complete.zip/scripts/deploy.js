// scripts/deploy.js
const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  // Deploy FX1NFT
  const FX1 = await hre.ethers.getContractFactory("FX1NFT");
  const fx1 = await FX1.deploy("FX1 Digital Hubs", "FDH", 1000, hre.ethers.parseEther("0.01"), "ipfs://");
  await fx1.waitForDeployment ? await fx1.waitForDeployment() : await fx1.deploymentTransaction().wait();
  console.log("FX1NFT deployed to:", fx1.target || fx1.address);

  // Deploy Marketplace
  const Marketplace = await hre.ethers.getContractFactory("Marketplace");
  const market = await Marketplace.deploy();
  await market.waitForDeployment ? await market.waitForDeployment() : await market.deploymentTransaction().wait();
  console.log("Marketplace deployed to:", market.target || market.address);

  console.log("Done");
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
