import express from 'express';
import dotenv from 'dotenv';
import { ethers } from 'ethers';

dotenv.config();
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 5000;
const provider = new ethers.JsonRpcProvider(process.env.BASE_MAINNET_RPC || process.env.BASE_SEPOLIA_RPC);

app.get('/', (req, res) => {
  res.send('FX1 NFT Marketplace Backend running');
});

app.get('/block', async (req, res) => {
  try {
    const block = await provider.getBlockNumber();
    res.json({ block });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => {
  console.log('Server running on port', PORT);
});
